################################################################################
# ESU explorer
#
# ESUexplorer.R
# Ulrike Niemann
#
################################################################################
#
# Anwendung starten: oben rechts Button "Run App"
#
if (!require("shiny")) {
  install.packages("shiny")
}
library("shiny")
runApp(launch.browser = TRUE)
#
################################################################################
